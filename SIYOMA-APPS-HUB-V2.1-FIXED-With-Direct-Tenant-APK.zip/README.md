# SIYOMA APPS HUB
Official static SIYOMA APPS HUB website.

## Catalogue
Available Now:
- SIYOMA Tenant & Rent Tracker (V2.1)

Under Review / Coming Soon:
- SIYOMA GroupWork Hub
- SIYOMA CU Library — Super Record Tracker
- SIYOMA Kenyan Comrade Academic Assistant

## Release safety
The current Tenant & Rent Tracker project archive is a signed test build. The website deliberately does not expose it as a public production download. Replace the release-status CTA with the verified production APK URL after final release testing.

## Netlify
Upload this repository to GitHub and import it into Netlify.
Build command: empty.
Publish directory: repository root.
Do not put Paystack secrets or other credentials in this repository.
